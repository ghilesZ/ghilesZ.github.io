package ast;
public abstract class ASTexpression{

  public abstract String toString();
  public abstract Object eval();

}
