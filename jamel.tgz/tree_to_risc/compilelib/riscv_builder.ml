open Treelib
open Asm

(** load immediate: li rd imm *)
let load_immediate ~temp ~imm =
  Oper
    {
      assem = "li `d0, " ^ imm;
      dst = [ temp ];
      src = [];
      jump = None;
      is_call = false;
    }

(** Move instruction: mv rd, rs *)
let move_instr ~dst ~src =
  match (Tree_helper.is_float_temp dst, Tree_helper.is_float_temp src) with
  | true, true -> Move { assem = "fmv.d `d0, `s0"; dst; src }
  | false, false -> Move { assem = "mv `d0, `s0"; dst; src }
  | _ ->
      failwith
        (Format.asprintf
           "move between two temporaries of different types: %s and %s" dst src)

(** Parameter binding to physical register *)
let move_param ~dst ~src =
  Oper
    {
      assem =
        (if Tree_helper.is_float_temp dst then "fmv.d `d0, " ^ src
         else "mv `d0, " ^ src);
      dst = [ dst ];
      src = [];
      jump = None;
      is_call = false;
    }

(** Move instruction: mv rd, rs *)
let return_value ~dst =
  Oper
    {
      assem =
        (if Tree_helper.is_float_temp dst then "fmv.d `d0, fa0"
         else "mv `d0, a0");
      dst = [ dst ];
      src = [];
      jump = None;
      is_call = false;
    }

(** Binary instruction: op rd, rs1, rs2 *)
let binary_instr ~op ~dst ~src1 ~src2 =
  Oper
    {
      assem = op ^ " `d0, `s0, `s1";
      dst = [ dst ];
      src = [ src1; src2 ];
      jump = None;
      is_call = false;
    }

(** Binary instruction with immediate: op rd, rs, imm *)
let binary_instr_i ~op ~dst ~src imm =
  Oper
    {
      assem = op ^ " `d0, `s0, " ^ imm;
      dst = [ dst ];
      src = [ src ];
      jump = None;
      is_call = false;
    }

let label l = Label { assem = l ^ ":"; lab = l }

