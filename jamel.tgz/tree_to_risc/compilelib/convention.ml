open Treelib
open! Utils
open Asm

(* Frame layout (low -> high addresses)
-----------------------------------
| local spill        |
| caller-save regs   |
| saved ra           |
| saved s regs       |
| saved fs regs      |
*)

(* Return the set of callee-saved physical registers that are actually used
   in the current coloring.
   Temps that are not present in [colors] (i.e., spilled temporaries)
   are simply ignored. This function only reasons about physical registers
   that were successfully assigned by the register allocator.
*)
let used_callee_saved registers colors =
  SMap.fold
    (fun _temp reg acc ->
      if List.exists (fun r -> r.name = reg.name && r.save = Callee) registers
      then RSet.add reg acc
      else acc)
    colors RSet.empty

(* Return the set of caller-saved physical registers that are actually used
   in the current coloring.
   Temps that are not present in [colors] (i.e., spilled temporaries)
   are simply ignored. This function only reasons about physical registers
   that were successfully assigned by the register allocator.
*)
let used_caller_saved (registers : reg list) colors =
  SMap.fold
    (fun _temp reg acc ->
      if List.exists (fun r -> r.name = reg.name && r.save = Caller) registers
      then RSet.add reg acc
      else acc)
    colors RSet.empty


(* -------------------------------------------------------------------------- *)
(* Final assembly rewriting stage responsible for inserting calling
   convention machinery around the register-allocated code.

   It performs two main tasks:
   1) Prologue / Epilogue generation
      - Determines which callee-saved registers are actually used
        (based on the coloring maps).
      - Computes the required stack frame size (ABI-aligned).
      - Generates:
          * Prologue: adjust stack pointer, save ra, save used callee-saved
            integer and floating-point registers.
          * Epilogue: restore saved registers, restore ra, reset stack
            pointer, and return.
   2) Call rewriting
      - For each function call instruction, inserts code to save and
        restore caller-saved registers around the call.

   Inputs:
     - colors / fcolors : register allocation maps (int and float).
     - registers     : list of registers.
     - instrs           : body instructions (after register allocation).
     - spills           : space needed for spill temporaries.

   output:
     - The rewritten instruction list (with caller-save handling),
     - The routine's prologue,
     - The routine's epilogue.
*)

let generate (colors : reg SMap.t) (registers : reg list)
    (instrs : Asm.physical_asm) (spills : int) (live_across : Asm.reg list) =
  (instrs)
