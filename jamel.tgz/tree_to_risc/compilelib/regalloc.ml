open Treelib
open Utils
open Asm

exception RegallocException of string

type info = { live_in : SSet.t; live_out : SSet.t }

let use (i : Tree.temp Asm.instr) : SSet.t =
  match i with
  | Oper { src; _ } -> SSet.of_list src
  | Move { src; _ } -> SSet.singleton src
  | Label _ -> SSet.empty

let def (i : Tree.temp Asm.instr) : SSet.t =
  match i with
  | Oper { dst; _ } -> SSet.of_list dst
  | Move { dst; _ } -> SSet.singleton dst
  | Label _ -> SSet.empty

(* Computes the set of temporaries that are live accross calls. Those
   should ideally be placed in a Callee save registers so that there's
   no need to save them when dealing with call conventions. Other than
   that, temporaries should preferably be placed in caller-save
   registers *)
let live_across_calls (instrs : Asm.virtual_asm) (live : info array) : SSet.t =
  List.fold_left
    (fun (acc, i) instr ->
      match instr with
      | Asm.Oper { is_call = true; _ } ->
          (SSet.union acc live.(i).live_out, succ i)
      | _ -> (acc, succ i))
    (SSet.empty, 0) instrs
  |> fst

(* ---- Liveness analysis (backward dataflow) ---- *)
(* Computes live_in and live_out sets for each instruction using
   backward dataflow iteration until a fixed point.

   For each instruction i:
     live_out[i] = ⋃ live_in[s] for all successors s of i
     live_in[i]  = use[i] ∪ (live_out[i] − def[i])

   Algorithm:
   1. Initialize all live_in/live_out sets to empty.
   2. Repeatedly iterate backward over instructions:
        - Recompute live_out from successors.
        - Recompute live_in from use/def equations.
   3. Stop when no set changes (fixed point reached).
*)
let analyze (instrs : Asm.virtual_asm) : info array =
  raise (RegallocException (__FUNCTION__^" not implemented yet"))

(* ---- Interference graph construction ---- *)
(* Builds the integer and float interference graphs from liveness info.
   Returns (integer_graph, float_graph).
*)
let build_interference (instrs : Asm.virtual_asm) (live : info array) :
    Graph.t * Graph.t =
  raise (RegallocException (__FUNCTION__^" not implemented yet"))

(* ---- Simplify phase (graph reduction) ---- *)
(* Implements the simplify phase of graph coloring.

   Repeatedly:
     - Pick a node with degree < k if possible.
     - If none exists, pick an arbitrary node (potential spill).
     - Remove it from the graph and push it onto a stack.

   The resulting stack gives a reverse elimination order
   for coloring (low-degree nodes first when popping).

   A copy of the graph is used so the original is preserved.
*)
let simplify ~(k : int) (g : Graph.t) : string list =
  raise (RegallocException (__FUNCTION__ ^" not implemented yet"))

(* ---- Select phase (assign colors) ---- *)
(* Pops nodes from the simplify stack and assigns registers.

   For each temp t:
     - Collect the set of colors already assigned to its neighbors.
     - Choose a register from 'registers' not in that set.
     - If one exists, assign it.
     - Otherwise, mark t as spilled.

   Returns:
     - A mapping temp -> assigned register.
     - A list of spilled temps.
*)
let select ~(registers : Asm.reg list) ~(live_across : SSet.t) (g : Graph.t)
    (stack : string list) ~(precolored : (Tree.temp * Asm.reg) list) :
    Asm.reg SMap.t * string list =
  raise (RegallocException (__FUNCTION__ ^" not implemented yet"))

(* ---- Full graph coloring driver ---- *)
type colorization = { physical_bindings : reg SMap.t; spills : Tree.temp list }

let merge_colorization c1 c2 =
  let physical_bindings =
    SMap.union
      (fun k r1 r2 ->
        if r1 = r2 then Some r1
        else failwith ("Conflicting register assignment for " ^ k))
      c1.physical_bindings c2.physical_bindings
  in
  let spills = c1.spills @ c2.spills in
  { physical_bindings; spills }

let print_col fmt col =
  Format.fprintf fmt "%a"
    (SMap.print (fun fmt (original, assigned) ->
         Format.fprintf fmt "%s -> %s\n" original assigned.name))
    col.physical_bindings

(* Steps:
   1. Run simplify to compute elimination stack.
   2. Run select to assign registers and detect spills.
   3. Add precolored temps (fixed hardware registers) to the map.

   k = number of available registers.
   registers = list of allocatable registers.
   precolored = fixed temp -> register bindings.

   Returns:
     - Final temp -> register mapping.
     - List of spills (if any).
 *)
let color (registers : reg list) ~(precolored : (Tree.temp * reg) list)
    ~(live_across : SSet.t) (g : Graph.t) : colorization =
  let stack = simplify ~k:(List.length registers) g in
  let colormap, spills = select ~registers ~live_across g stack ~precolored in
  let colormap =
    List.fold_left (fun acc (t, r) -> SMap.add t r acc) colormap precolored
  in
  { physical_bindings = colormap; spills }

let get_colorizations (registers : reg list) ~precolored ~f_precolored
    (selected : Asm.virtual_asm) : colorization * SSet.t =
  let live = analyze selected in
  let ig, fg = build_interference selected live in
  let live_across = live_across_calls selected live in
  let int_regs = List.filter (fun r -> r.kind = Int) registers in
  let float_regs = List.filter (fun r -> r.kind = Float) registers in
  let col = color int_regs ~precolored ~live_across ig in
  let f_col = color float_regs ~precolored:f_precolored ~live_across fg in
  (merge_colorization col f_col, live_across)

(** Spill selected temporaries to the stack by rewriting the program. For each
    temporary in [spills]:
    - assigns a unique stack slot starting at [offset]
    - rewrites every use of the spilled temp to: load fresh_temp <- [sp + slot]
    - rewrites every definition of the spilled temp to: store fresh_temp ->
      [sp + slot]

    Fresh temporaries are generated via [rewriter] and preserve the original
    temp's type (int or float). Returns the rewritten program along with new
    frame size (original [offset] plus space reserved for spills) *)
let spill_temporaries (rewriter : Tree_helper.rewritter)
    (spills : Tree.temp list) (instrs : virtual_asm) (offset : int) :
    virtual_asm * int =
  raise (RegallocException (__FUNCTION__ ^" not implemented yet"))
