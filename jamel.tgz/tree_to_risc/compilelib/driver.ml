open Treelib
open Utils
open Regalloc

exception SpillException of string list

module Allocator (A : Backend.ARCH) = struct
  let assign_function col =
   fun t ->
    if SMap.mem t col.physical_bindings then SMap.find t col.physical_bindings
    else failwith ("uncolored temporary " ^ t)

  (** Attempts to allocate physical registers for the given virtual assembly. If
      some temporaries cannot be assigned (spill required), raises
      [SpillException] with the lists of integers and floats to spill.
      Otherwise, generates the function prologue and epilogue based on used
      callee-saved registers and the current stack offset. Returns the complete
      physical assembly including prologue, body, and epilogue. *)
  let colorize (selected : Asm.virtual_asm) (initial_offset : int) :
      Asm.physical_asm =
    let col, live_across =
      get_colorizations ~f_precolored:A.f_precolored ~precolored:A.precolored
        A.registers selected
    in
    if col.spills <> [] then raise (SpillException col.spills);
    let reg_of_temp = assign_function col in
    let post_register =
      List.map (Asm.assign_physical_register reg_of_temp) selected
    in
    let live_across = SSet.elements live_across |> List.map reg_of_temp in
    Convention.generate col.physical_bindings A.registers post_register
      initial_offset live_across

  (** Colorizes the given virtual assembly repeatedly by spilling temporaries to
      the stack if needed until no spill remains. *)
  let allocate rewriter (routine : Asm.virtual_asm) =
    let rec loop routine offset =
      try
        let allocated = colorize routine offset in
        (routine, allocated)
      with SpillException spills ->
        let spilled, off =
          Regalloc.spill_temporaries rewriter spills routine offset
        in
        loop spilled (off + offset)
    in
    loop routine 0
end

let routine oc name instrs =
  output_string oc ("\n# -------- Function " ^ name ^ " --------\n");
  let instrs' = List.filter (fun i -> not (Asm.is_noop i)) instrs in
  Format.asprintf "%a"
    (Format.pp_print_list ~pp_sep:Format.pp_print_newline Asm.print)
    instrs'
  |> output_string oc;
  output_string oc ("\n#-------- End of function " ^ name ^ " --------\n")

module Emit = struct
  module Sel = Select.Make (Riscv_tiler)
  module All = Allocator (Riscv_tiler)

  let data oc string_literals float_literals =
    if
      (not (SMap.is_empty string_literals))
      || not (SMap.is_empty float_literals)
    then (
      output_string oc ".section .rodata\n";
      SMap.iter
        (fun l s ->
          output_string oc (l ^ ":\n");
          output_string oc ("\t.string \"" ^ String.escaped s ^ "\"\n"))
        string_literals);

    if not (SMap.is_empty float_literals) then (
      output_string oc ".section .rodata\n";
      SMap.iter
        (fun lit lab ->
          output_string oc (lab ^ ":\n");
          output_string oc ("\t.double " ^ lit ^ "\n"))
        float_literals)

  let compile (prog : Tree.program) (filename : string) : unit =
    let loaded = Preload.build prog in
    let rewriter = Tree_helper.build_rewriter prog in
    let string_literals = Tree_helper.collect_litterals prog in
    let float_literals = Tree_helper.collect_float_litterals prog in
    let selected =
      SMap.map (Sel.select rewriter float_literals) loaded.routines
    in
    let asm_routines =
      SMap.mapi (fun name r -> (r, All.allocate rewriter r)) selected
    in
    let with_entries =
      SMap.mapi
        (fun name (preregister, (preregister_with_spills, postregister)) ->
          let entry =
            Riscv_builder.label (if name = "main" then "ILPmain" else name)
          in

          ( entry :: preregister,
            (entry :: preregister_with_spills, entry :: postregister) ))
        asm_routines
    in
    let oc_asm = open_out (filename ^ ".asm") in
    let oc_spill = open_out (filename ^ ".spilled") in
    let oc = open_out (filename ^ ".s") in
    data oc string_literals float_literals;
    output_string oc Riscv_tiler.file_prologue;
    SMap.iter
      (fun name (preregister, (preregister_with_spills, postregister)) ->
        routine oc_asm name preregister;
        routine oc_spill name preregister_with_spills;
        routine oc name postregister)
      with_entries;
    output_string oc Riscv_tiler.file_epilogue;
    close_out oc_asm;
    close_out oc_spill;
    close_out oc
end
