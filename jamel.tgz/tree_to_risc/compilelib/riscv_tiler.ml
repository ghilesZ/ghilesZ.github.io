open Treelib
open Tree
open Tree_helper
open! Asm
open! Backend

let registers : reg list =
  [
    (* integer temporaries (caller-saved) *)
    { name = "t0"; save = Caller; kind = Int };
    { name = "t1"; save = Caller; kind = Int };
    { name = "t2"; save = Caller; kind = Int };
    { name = "t3"; save = Caller; kind = Int };
    { name = "t4"; save = Caller; kind = Int };
    { name = "t5"; save = Caller; kind = Int };
    { name = "t6"; save = Caller; kind = Int };
    (* integer saved (callee-saved) *)
    { name = "s0"; save = Callee; kind = Int };
    { name = "s1"; save = Callee; kind = Int };
    { name = "s2"; save = Callee; kind = Int };
    { name = "s3"; save = Callee; kind = Int };
    { name = "s4"; save = Callee; kind = Int };
    { name = "s5"; save = Callee; kind = Int };
    { name = "s6"; save = Callee; kind = Int };
    { name = "s7"; save = Callee; kind = Int };
    { name = "s8"; save = Callee; kind = Int };
    { name = "s9"; save = Callee; kind = Int };
    { name = "s10"; save = Callee; kind = Int };
    { name = "s11"; save = Callee; kind = Int };
    (* floating temporaries (caller-saved) *)
    { name = "ft0"; save = Caller; kind = Float };
    { name = "ft1"; save = Caller; kind = Float };
    { name = "ft2"; save = Caller; kind = Float };
    { name = "ft3"; save = Caller; kind = Float };
    { name = "ft4"; save = Caller; kind = Float };
    { name = "ft5"; save = Caller; kind = Float };
    { name = "ft6"; save = Caller; kind = Float };
    { name = "ft7"; save = Caller; kind = Float };
    { name = "ft8"; save = Caller; kind = Float };
    { name = "ft9"; save = Caller; kind = Float };
    { name = "ft10"; save = Caller; kind = Float };
    { name = "ft11"; save = Caller; kind = Float };
    (* floating saved (callee-saved) *)
    { name = "fs0"; save = Callee; kind = Float };
    { name = "fs1"; save = Callee; kind = Float };
    { name = "fs2"; save = Callee; kind = Float };
    { name = "fs3"; save = Callee; kind = Float };
    { name = "fs4"; save = Callee; kind = Float };
    { name = "fs5"; save = Callee; kind = Float };
    { name = "fs6"; save = Callee; kind = Float };
    { name = "fs7"; save = Callee; kind = Float };
    { name = "fs8"; save = Callee; kind = Float };
    { name = "fs9"; save = Callee; kind = Float };
    { name = "fs10"; save = Callee; kind = Float };
    { name = "fs11"; save = Callee; kind = Float };
  ]

let precolored =
  [
    ("rv", { name = "a0"; save = Caller; kind = Int });
    ("sp", { name = "sp"; save = Callee; kind = Int });
  ]

let f_precolored = [ ("fv", { name = "fa0"; save = Caller; kind = Float }) ]

let asm_of_binop = function
  (* integer *)
  | Add -> "add"
  | Sub -> "sub"
  | Mul -> "mul"
  | Div -> "div"
  | And -> "and"
  | Or -> "or"
  | Xor -> "xor"
  | Mod -> "rem"
  (* floating-point *)
  | AddF -> "fadd.d"
  | SubF -> "fsub.d"
  | MulF -> "fmul.d"
  | DivF -> "fdiv.d"
  (* integer shifts *)
  | LShift -> "sll"
  | RShift -> "srl"
  | ARshift -> "sra"


(* Add parameter move insertion at function entry *)
let param_moves params =
  List.mapi
    (fun i temp ->
      let reg =
        if Tree_helper.is_float_temp temp then "fa" ^ string_of_int i
        else "a" ^ string_of_int i
      in
      Riscv_builder.move_param ~dst:temp ~src:reg)
    params

(* Lowers a single IR statement (Tree.stmt) into one or more RISC-V assembly
   instructions (Asm.instr).
   The rewriter 'r' is used to generate fresh temporaries when needed
   expr_to_temp: ensures that an IR expression is evaluated and its value is stored
   in a temporary register.

   - If the expression is already a Temp, it simply returns that temp.
   - Otherwise, it generates the necessary instructions to compute the
     expression into a fresh temporary and returns that temp.

   This guarantees that instruction selection always works with
   register operands (temps), not complex IR expressions.
 *)
let munch_stm (r : rewritter) (expr_to_temp : ?dst:temp -> expr -> temp)
    (s : stmt) =
  match s.payload with
  | Tree.Move ({ payload = Temp t; _ }, src) ->
      let ts = expr_to_temp ~dst:t src in
      if ts <> t then [ Riscv_builder.move_instr ~dst:t ~src:ts ] else []
  | Label "end" -> []
  | _ ->
      failwith
        (Format.asprintf
           "Tiling error in %s: could not find a tile for statement %a"
           __FUNCTION__ print_stmt s)

(* Instruction-selection tile for integer constants.
   This tile matches IR expressions of the form:
       Const n

   When selected, it:
     1. Creates a fresh temporary register.
     2. Emits a single "load immediate" instruction that loads
        the constant value n into that temporary.
     3. Returns the generated instruction along with the temp
        holding the result. *)
let tile_const r =
  {
    cost = 1;
    matches_exp = (function { payload = Const _; _ } -> true | _ -> false);
    emit_exp =
      (fun ?dst _ e _ ->
        match (dst, e.payload) with
        | None, Const n ->
            let t = r.fresh_temp Int in
            ([ Riscv_builder.load_immediate ~temp:t ~imm:n ], t)
        | Some d, Const n -> ([ Riscv_builder.load_immediate ~temp:d ~imm:n ], d)
        | _ -> assert false);
  }


let tiles r =
  [
    tile_const r;
  ]

let file_prologue =
  ".text\n\
   .globl main\n\
   main:\n\
   addi sp, sp, -32        # make space for ra + s0 + s1\n\
   sd ra, 24(sp)\n\
   sd s0, 16(sp)\n\
   sd s1, 8(sp)\n\
   # --- Read start cycle ---\n\
   rdcycle s0               # s0 = start cycles\n\
   # Call ILPmain\n\
   jal ra, ILPmain\n\
   # --- Read end cycle ---\n\
   rdcycle s1               # s1 = end cycles\n\
   # Call report_cycles(start=s0, end=s1)\n\
   mv a0, s0\n\
   mv a1, s1\n\
   jal ra, report_cycles\n\
   li a0, 0                # return value for main\n\
   ld ra, 24(sp)\n\
   ld s0, 16(sp)\n\
   ld s1, 8(sp)\n\
   addi sp, sp, 32\n\
   ret\n"

let file_epilogue = ""
