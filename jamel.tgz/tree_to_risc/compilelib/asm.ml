open Treelib
open Utils

(* generic type for physical registers *)
type save = Caller | Callee
type reg = { name : string; save : save; kind : Tree.typ }

(* Abstract assembly language *)
type 'a instr =
  | Oper of {
      assem : string;
      dst : 'a list;
      src : 'a list;
      jump : Tree.label list option;
      is_call : bool;
    }
    (* an operation reads a set of temporaries, writes into an other set
   and might (or not) jump to a set of labels *)
  | Move of { assem : string; dst : 'a; src : 'a }
  | Label of { assem : string; lab : Tree.label }

type virtual_instr = Tree.temp instr
type physical_instr = reg instr

let print fmt = function
  | Oper { assem; _ } -> Format.fprintf fmt "%s" assem
  | Move { assem; _ } -> Format.fprintf fmt "%s" assem
  | Label { assem; _ } -> Format.fprintf fmt "%s" assem

type virtual_asm = Tree.temp instr list
type physical_asm = reg instr list

module RSet = Set.Make (struct
  type t = reg

  let compare = compare
end)

(** helper to collect temporaries that appear in a list of asm instructions *)
let collect_temps (instrs : virtual_asm) : SSet.t =
  let add_instr acc = function
    | Oper { dst; src; _ } ->
        List.fold_left (fun acc x -> SSet.add x acc) acc (src @ dst)
    | Move { dst; src; _ } -> acc |> SSet.add dst |> SSet.add src
    | Label _ -> acc
  in
  List.fold_left add_instr SSet.empty instrs

(* Rewrites an abstract assembly instruction by replacing temporary
   registers with their assigned physical registers.

   The function takes:
     - reg_of_temp : temp -> physical register mapping
     - i           : an abstract assembly instruction

   Assembly templates use placeholders:
     - `d0, `d1, ... for destination operands
     - `s0, `s1, ... for source operands

   For each operand:
     1. The temporary is mapped to its physical register.
     2. The placeholder in the assembly string is replaced.
     3. The dst/src lists are updated to contain physical registers. *)
let assign_physical_register (reg_of_temp : Tree.temp -> reg)
    (i : virtual_instr) : physical_instr =
  let subst reg_of_temp assem ~dst ~src =
    let s = ref assem in
    let dst =
      List.mapi
        (fun i t ->
          let physical = reg_of_temp t in
          s :=
            Str.global_replace
              (Str.regexp ("`d" ^ string_of_int i))
              physical.name !s;
          physical)
        dst
    in
    let src =
      List.mapi
        (fun i t ->
          let physical = reg_of_temp t in
          s :=
            Str.global_replace
              (Str.regexp ("`s" ^ string_of_int i))
              physical.name !s;
          physical)
        src
    in
    (!s, dst, src)
  in
  match i with
  | Label l -> Label l
  | Move { assem; dst; src } ->
      let assem, dst, src = subst reg_of_temp assem ~dst:[ dst ] ~src:[ src ] in
      Move { assem; dst = List.hd dst; src = List.hd src }
  | Oper ({ assem; dst; src; _ } as o) ->
      let assem, dst, src = subst reg_of_temp assem ~dst ~src in
      Oper { o with assem; dst; src }

(* Constructs the control-flow graph (CFG) successor relation
   for a list of assembly instructions.

   For each instruction i:
     - If it contains explicit jump targets (jump = Some labels),
       successors are the corresponding label positions.
     - Otherwise (normal instruction), control flows to i + 1,
       unless it is the last instruction.

   The result is an array where arr.(i) is the list of successor
   instruction indices.
*)
let build_succ instrs =
  let label_map =
    let tbl = Hashtbl.create 16 in
    List.iteri
      (fun i -> function Label { lab; _ } -> Hashtbl.add tbl lab i | _ -> ())
      instrs;
    tbl
  in
  let n = List.length instrs in
  let arr = Array.make n [] in
  List.iteri
    (fun i instr ->
      let succ =
        match instr with
        | Oper { jump = Some labs; _ } -> List.map (Hashtbl.find label_map) labs
        | Oper { jump = None; _ } | Move _ | Label _ ->
            if i + 1 < n then [ i + 1 ] else []
      in
      arr.(i) <- succ)
    instrs;
  arr

let escape s = String.map (function '"' -> '\'' | c -> c) s
let instr_label i instr = Format.asprintf "%d: %a" i print instr

let to_dot (instrs : virtual_asm) (out : out_channel) =
  let succ = build_succ instrs in
  output_string out "digraph CFG {\n";
  output_string out "  node [shape=box fontname=\"monospace\"];\n";
  (* Nodes *)
  List.iteri
    (fun i instr ->
      Printf.fprintf out "  n%d [label=\"%s\"];\n" i (instr_label i instr))
    instrs;
  (* Edges *)
  Array.iteri
    (fun i succs ->
      List.iter (fun j -> Printf.fprintf out "  n%d -> n%d;\n" i j) succs)
    succ;
  output_string out "}\n"

let is_noop = function Move { src; dst; _ } -> src = dst | _ -> false
